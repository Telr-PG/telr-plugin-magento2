<?php

namespace Telr\TelrPayments\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Vault\Api\PaymentTokenManagementInterface;

class TelrPaymentsConfigProvider implements ConfigProviderInterface
{
    protected $methodCode = "telr_telrpayments";

    protected $method;
    protected $paymentTokenManagement;
    protected $customerSession;

    public function __construct(
        PaymentHelper $paymentHelper,
        \Magento\Customer\Model\Session $customerSession,
        PaymentTokenManagementInterface $paymentTokenManagement
    ) {
        $this->customerSession = $customerSession;
        $this->paymentTokenManagement = $paymentTokenManagement;
        $this->method = $paymentHelper->getMethodInstance($this->methodCode);
    }

    public function getConfig()
    {
        $savedCards = array();

        if($this->customerSession->isLoggedIn()){
            $customerId = $this->customerSession->getCustomerId();
            $savedCardsList = $this->paymentTokenManagement->getListByCustomerId($customerId);
            foreach ($savedCardsList as $currentCard) {
                if($currentCard['is_active'] == 1 && $currentCard['is_visible'] == 1 && $currentCard['payment_method_code'] == 'telr_telrpayments'){
                    $cardDetails = json_decode($currentCard->getDetails(), true);

                    $cardName = (isset($cardDetails['type'])) ? $cardDetails['type'] : '';
                    $cardEnding = (isset($cardDetails['last4'])) ? $cardDetails['last4'] : '';
                    $cardExpMonth = (isset($cardDetails['expiry_month'])) ? $cardDetails['expiry_month'] : '';
                    $cardExpYear = (isset($cardDetails['expiry_year'])) ? $cardDetails['expiry_year'] : '';

                    $cardObj = array(
                        'txn_id' => $currentCard->getGatewayToken(),
                        'name' => $cardName . " ending with " . $cardEnding . " Expiry(" . $cardExpMonth . "/" . $cardExpYear . ")"
                    );

                    $savedCards[] = $cardObj;
                }   
            }
        }

        return $this->method->isAvailable() ? [
            'payment' => [
                'telr_telrpayments' => [
                    'redirectUrl' => $this->getRedirectUrl(),
                    'iframeUrl' => $this->getIframeUrl(),
                    'frameMode' => $this->getFramedMode(),
                    'savedCards' => json_encode($savedCards)
                ]
            ]
        ] : [];
    }

    protected function getRedirectUrl()
    {
        return $this->method->getRedirectUrl();
    }

    protected function getIframeUrl()
    {
        return $this->method->getIframeUrl();
    }

    protected function getFramedMode()
    {
        return $this->method->getFramedMode();
    }
}
