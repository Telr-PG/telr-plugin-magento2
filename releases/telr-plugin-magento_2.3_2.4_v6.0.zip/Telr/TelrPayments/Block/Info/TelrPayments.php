<?php

namespace Telr\TelrPayments\Block\Info;

class TelrPayments extends \Magento\Payment\Block\Info
{
    protected $_template = 'Telr_TelrPayments::info/telrpayments.phtml';
}
