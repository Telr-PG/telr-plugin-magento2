define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/action/place-order',
        'Magento_Checkout/js/action/select-payment-method',
        'Magento_Customer/js/model/customer',
        'Magento_Checkout/js/checkout-data',
        'Magento_Checkout/js/model/payment/additional-validators'
    ],
    function ($, Component, placeOrderAction, selectPaymentMethodAction, customer, checkoutData, additionalValidators) {
        'use strict';
        return Component.extend({
            defaults: {
                template: 'Telr_TelrPayments/payment/telr'
            },
            initialize: function() {
                this._super();
                window.telrloaded = false;
                console.log("Loading");
                console.log(window.checkoutConfig.payment.telr_telrpayments.savedCards);
                if(window.checkoutConfig.payment.telr_telrpayments.frameMode == 'yes'){
                    window.telrloadedInt = setInterval(function(){
                        if(!window.telrloaded){
                            if($("#payment_method_telr .payment-method-content").length == 1){
                                var frameHeight = 280;
                                //30 + 110
                                var cardsObj = JSON.parse(window.checkoutConfig.payment.telr_telrpayments.savedCards);
                                if(cardsObj.length > 0){
                                    frameHeight += 30;
                                    frameHeight += (cardsObj.length * 110);
                                }
                                var iframeUrl = "https://secure.telr.com/jssdk/token_frame.html?token=" + Math.floor((Math.random() * 9999999999) + 1);
;
                                var iframeHtml = ' <iframe id="telr_iframe" src= "' + iframeUrl + '" style="width: 100%; height: ' + frameHeight + 'px; border: 0;margin-top: 20px;" sandbox="allow-forms allow-modals allow-popups-to-escape-sandbox allow-popups allow-scripts allow-top-navigation allow-same-origin"></iframe>';
                                $("#payment_method_telr .payment-method-content").prepend(iframeHtml);
                                window.telrloaded = true;
                                clearInterval(window.telrloadedInt);

                                var b;
                                // you might want to write these into if statements to make sure that e.data[0] is varA if you have multiple messages coming across
                                if (typeof window.addEventListener != 'undefined') {
                                    window.addEventListener('message', function(e) {
                                        var token = e.data;
                                        console.log(token);
                                        if(token['payment_token'] != undefined){
                                            console.log("Telr Token Received 1!");
                                            $("#telr_payment_token").val(token['payment_token']);
                                        }
                                    }, false);
                                } else if (typeof window.attachEvent != 'undefined') { // this part is for IE8
                                    window.attachEvent('onmessage', function(e) {
                                        var token = e.data;
                                        console.log(token);
                                        if(token['payment_token'] != undefined){
                                            console.log("Telr Token Received 2!");
                                            $("#telr_payment_token").val(token['payment_token']);
                                        }
                                    });
                                }

                                setTimeout(function(){
                                    console.log("Sending Token");
                                    document.getElementById('telr_iframe').contentWindow.postMessage(window.checkoutConfig.payment.telr_telrpayments.savedCards,"*");
                                }, 1000);
                            }
                        }
                    }, 1000);
                }
            },
            placeOrder: function (data, event) {
                if (event) {
                    event.preventDefault();
                }
                var self = this,
                    placeOrder,
                    emailValidationResult = customer.isLoggedIn(),
                    loginFormSelector = 'form[data-role=email-with-possible-login]';
                if (!customer.isLoggedIn()) {
                    $(loginFormSelector).validation();
                    emailValidationResult = Boolean($(loginFormSelector + ' input[name=username]').valid());
                }
                if (emailValidationResult && this.validate() && additionalValidators.validate() && ($("#telr_payment_token").val() != '' || window.checkoutConfig.payment.telr_telrpayments.frameMode != 'yes')) {
                    this.isPlaceOrderActionAllowed(false);
                    placeOrder = placeOrderAction(this.getData(), false, this.messageContainer);

                    $.when(placeOrder).fail(function () {
                        self.isPlaceOrderActionAllowed(true);
                    }).done(this.afterPlaceOrder.bind(this));

                    return true;
                }
                return false;
            },
            getData: function () {
                var saveCard = 'no';
                if($("#payment_method_telr .save-card-option input").length == 1){
                    if($("#payment_method_telr .save-card-option input").is(":checked")){
                        saveCard = 'yes';
                    }
                }
                var data = {
                    'method': this.getCode(),
                    'additional_data': {
                        'payment_token': $("#telr_payment_token").val(),
                        'save_card': saveCard
                    }
                }
                console.log(data);
                return data;
            },
            afterPlaceOrder: function () {
                if(window.checkoutConfig.payment.telr_telrpayments.frameMode == 'yes' && false){
                    $.ajax({
                        url : window.checkoutConfig.payment.telr_telrpayments.iframeUrl,
                        type: "GET",
                        success: function (iframeUrl) {
                            var iframeHtml = ' <iframe id="telr" src= "' + iframeUrl + '" style="width: 100%; height: 450px; border: 0;" sandbox="allow-forms allow-modals allow-popups-to-escape-sandbox allow-popups allow-scripts allow-top-navigation allow-same-origin"></iframe>';
                            $(".payment-method._active .payment-method-content").html(iframeHtml);
                        },
                        error: function (response) {
                        }
                    });
                }else{
                    $.mage.redirect(window.checkoutConfig.payment.telr_telrpayments.redirectUrl);
                }
            },
            isVaultEnabled: function () {
                    return true;
            },
            isLoggedIn: function () {
                    return customer.isLoggedIn();
            },
            CreateGuid: function (){  
               function _p8(s) {  
                  var p = (Math.random().toString(16)+"000000000").substr(2,8);  
                  return s ? "-" + p.substr(0,4) + "-" + p.substr(4,4) : p ;  
               }  
               return _p8() + _p8(true) + _p8(true) + _p8();  
            }
        });
    }
);
