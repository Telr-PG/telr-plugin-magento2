<?php

namespace Telr\TelrPayments\Controller\Standard;

class Redirect extends \Telr\TelrPayments\Controller\TelrPayments {

    public function execute() {
        $order = $this->getOrder();

        if ($order->getBillingAddress()) {
            $payment_url = $this->getTelrModel()->buildTelrRequest($order);
            if ($payment_url) {
              $this->getResponse()->setRedirect($payment_url);
            } else {
              $this->_cancelPayment();
              $this->_checkoutSession->restoreQuote();
              $this->messageManager->addError(__('Sorry, unable to process your transaction at this time.'));
              $this->getResponse()->setRedirect($this->getTelrHelper()->getUrl('checkout/cart'));
            }
        } else {
            $this->_cancelPayment();
            $this->_checkoutSession->restoreQuote();
            $this->getResponse()->setRedirect($this->getTelrHelper()->getUrl('checkout'));
        }
    }

}
