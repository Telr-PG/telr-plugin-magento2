<?php

namespace Telr\TelrPayments\Block\Form;

class TelrPayments extends \Magento\Payment\Block\Form
{
    protected $_template = 'Telr_TelrPayments::form/telrpayments.phtml';
}
