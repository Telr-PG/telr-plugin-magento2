<?php

namespace Telr\TelrPayments\Controller\Standard;

class Validateapplepay extends \Telr\TelrPayments\Controller\TelrPayments {

    public function execute()
    {
        $valURL = (string) $this->getRequest()->getParam('valURL', '');
        $host   = parse_url($valURL, PHP_URL_HOST);

        if (parse_url($valURL, PHP_URL_SCHEME) !== 'https'
            || !is_string($host)
            || substr($host, -10) !== '.apple.com'
        ) {
            return $this->_resultJsonFactory->create()
                ->setHttpResponseCode(400)
                ->setData(['error' => 'Invalid validation URL']);
        }

        $responseParams = $this->getRequest()->getParams();
        $certificate_key =  BP .'/upload/telr/certificate_keys/' . $this->getTelrApplePayModel()->getConfig('key_pem');
        $certificate_path = BP .'/upload/telr/certificate_keys/' . $this->getTelrApplePayModel()->getConfig('cert_pem');
        $read = $this->_driver->create($certificate_path, \Magento\Framework\Filesystem\DriverPool::FILE);
        $fileData = $read->readAll();
        $merchantidentifier = $this->getTelrApplePayModel()->getConfig('apple_merchant_id');
        $certificate_pass = $this->getTelrApplePayModel()->getConfig('key_password');
        $domainName = $this->getTelrApplePayModel()->getConfig('apple_domain_name');
        $displayName = $this->getTelrApplePayModel()->getConfig('apple_display_name');

        $data = json_decode('{"merchantIdentifier":"'.$merchantidentifier.'", "domainName":"'.$domainName.'", "displayName":"'.$displayName.'"}');

        $result = $this->_telrHelper->callApi($data, $valURL, $certificate_key, $certificate_path, $certificate_pass);
        $jsonResult = $this->_resultJsonFactory->create();
        $jsonResult->setData($result);
        return $jsonResult;
    }
}
